<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
		<![endif]-->
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400,700%3Alatin%7CMontserrat%3A700%3Alatin"/>
	<link rel="stylesheet" href="<?=  base_url()?>assets/css/style.css"/>
	<link rel="stylesheet" href="<?=  base_url()?>assets/css/prettyPhoto.css"/>
	
        <script type="text/javascript" src="<?=  base_url()?>assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="<?=  base_url()?>assets/js/isotope.js"></script>
	<script type="text/javascript" src="<?=  base_url()?>assets/js/imagesloaded.js"></script>
	<script type="text/javascript" src="<?=  base_url()?>assets/js/modernizr.custom.24530.js"></script>
        <script type="text/javascript" src="<?=  base_url()?>assets/js/almond.js"></script>
<script type="text/javascript" src="<?=  base_url()?>assets/js/underscore.js"></script>

<script type="text/javascript" src="<?=  base_url()?>assets/js/jquery.prettyPhoto.js"></script>
<script type="text/javascript" src="<?=  base_url()?>assets/js/header_carousel.js"></script>
<script type="text/javascript" src="<?=  base_url()?>assets/js/sticky_navbar.js"></script>
<script type="text/javascript" src="<?=  base_url()?>assets/js/simplemap.js"></script>
<script type="text/javascript" src="<?=  base_url()?>assets/js/main.min.js"></script>
<script type="text/javascript" src="<?=  base_url()?>assets/js/main.js"></script>
<script type="text/javascript" src="<?=  base_url()?>assets/js/require.js"></script>