<footer>
		<!--<div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-md-4">
						<div class="widget  widget_text  push-down-30">
							<h6 class="footer__headings">ABOUT US</h6>	
							<div class="textwidget">
								<img src="images/logo_footer.png" alt="Footer Logo" width="218" height="45" />
								<br><br>
								Our construction management professionals organize, lead and manage the people, materials and processes of 
								truction utilizing construction management professionals.
								<br><br>
								<strong><a href="#" class="read-more" target="_blank">READ MORE</a></strong>
							</div>
						</div>
					</div>
					<div class="col-xs-12  col-md-4">
						<div class="widget  widget_nav_menu  push-down-30">
							<h6 class="footer__headings">NAVIGATION</h6>
							<div class="menu-top-menu-container">
								<ul id="menu-top-menu-1" class="menu">
									<li><a href="extras.html">Extras</a>
										<ul class="sub-menu">
											<li><a href="shortcodes.html">Shortcodes</a></li>
											<li><a href="tables.html">Tables</a></li>
											<li><a href="brochure-box.html">Brochure Box</a></li>
										</ul>
									</li>
									<li><a href="alternative-page.html">Alternative Pages</a>
										<ul class="sub-menu">
											<li><a href="shop-front.html">Home for Shop</a></li>
											<li><a href="contact-multiple-locations.html">Multiple Contacts</a></li>
											<li><a href="team-contact-combined.html">Team &#038; Contact</a></li>
										</ul>
									</li>
									<li>
										<a target="_blank" href="http://www.weblusive-themes.com/buildpress/documentation">Online Documentation</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-xs-12  col-md-4">
						<div class="widget  widget_text  push-down-30">
							<h6 class="footer__headings">BUY NOW</h6>	
							<div class="textwidget">
								If you come all the way down here, you probably really like our BuildPress theme. To save you all the 
								troubles finding where to buy this theme, we have a solution for that too. Just click the button below.
								<br><br>
								<a class="btn  btn-primary" href="#" target="_blank">BUY NOW</a>
							</div>
						</div>
					</div>	
				</div>
			</div>
		</div>-->
		<div class="footer-bottom">
			<div class="container">
				<div class="footer-bottom__left">
				 POR  <a href="#" target="_blank">NANO</a>	
				</div>
				<div class="footer-bottom__right">
					&copy; 20<?php echo date('y');?><strong> IOM</strong>- IMPRENSA OFICIAL DOS MUNICÍPIOS	
				</div>
			</div>
		</div>
	</footer>




</body>
</html>