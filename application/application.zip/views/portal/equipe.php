 <div class="gray_bg">
        <div class="container">
          <div class="row welcome_inner">
            <div class="span12">
                    <h1><span class="colored">///</span> Equipe</h1>
              </div>
            
               
            </div>
        </div>
    </div>
     <div class="bg-separa" style="height:40px">
          
      <div class="container inner_content">
        <span class="txt-bgsepara">Conheça os profissionais</span>
          
          
      </div>
    </div>
    <!--/WELCOME AREA-->
    <!--MAIN CONTENT AREA-->
    <div class="container inner_content" >
      Em construção.</div>