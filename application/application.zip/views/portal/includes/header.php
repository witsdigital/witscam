
    <body>
    <!--TOP-->
    <div class="top_line"></div>
    <div class="panel hidden-phone">
        <div id="map">
        </div>
    </div>
    <!--/TOP-->
    <!--HEADER-->
    <header>


<div class="container">
            <div class="row hidden-phone">
                
            </div>
            <div class="row">
                <div class="span4 logo">
                    <a href="<?=  base_url('portal')?>"><img src="<?=  base_url()?>assets_portal/img/iom.png" alt="logo" width="698" height="115" style="margin-bottom:7px; margin-top:7px;" /></a>
                </div>
                <div class="span8">
                    <nav id="main-nav">
                        <ul id="menu">
                            <li><a href="<?=  base_url('portal')?>">Inicio</a>
                              
                            </li>
                            <li ><a href="#"> Quem somos </a>
                                <ul>
                                    <li><a href="<?=  base_url('portal/quemsomos')?>">Missão</a></li>
                                     <li><a href="<?=  base_url('portal/quemsomos')?>">Valores</a></li>
                                   
                               
                                   
                                   
                                </ul>
                            </li>
                            <li><a href="<?=  base_url('portal/sistemas')?>">Sistemas</a></li>
                            <li><a href="#">Publicações</a>
                             <ul>
                                 <li><a href="<?= base_url('portal/camaras')?>">Câmaras</a></li>
                                     <li><a href="<?= base_url('portal/prefeituras')?>">Prefeituras</a></li>
                                           <li><a href="<?= base_url('portal/autarquias')?>">Autarquias</a></li>
                               
                                   
                                   
                                </ul>
                            
                            
                            </li>
                            
                            <li><a href="<?=  base_url('portal/equipe')?>">Equipe</a>
                                
                            </li>
                          
                            <li><a href="#">Contato</a></li>
                        </ul>
                    </nav><!-- end #main-nav -->
                </div>
            </div>
		</div>
</header>