    <!--FOOTER-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="span3">
                    <img src="<?=  base_url()?>assets_portal/img/iom_neg.png" alt="logo" width="212" height="81" style="margin-bottom:7px; margin-top:7px;" />
                <hr class="visible-phone">
              </div>
                <div class="span3">
                    <h5><span class="txt-bgsepara">///</span>COMPANHIA IOM</h5>
                    <p>Empresa de Publicação e transparência municipal.</p>
                    <hr class="visible-phone">
                </div>
                <div class="span3 flickr">
                    <h5><span class="txt-bgsepara">///</span> CONTATOS</h5>
                  <span><strong  class="txt-bgsepara">Suporte:</strong> 77 0000 - 0000</span>
                    <p><strong class="txt-bgsepara">Vendas:</strong> 77 0000 - 0000 </p>
                    <hr class="visible-phone">
                </div>
                <div class="span3 soc_icons">
                    <h5><span class="txt-bgsepara">///</span>Ajude-nos a ser lÍDER</h5>
                    <span>Compartilhe e faça da IOM a melhor opção.</span>
                    <hr>
                    <a href="#"><div class="icon_t"></div></a>
                    <a href="#"><div class="icon_facebook"></div></a>
                    <a href="#"><div class="icon_dribbble"></div></a>
                    <a href="#"><div class="icon_google"></div></a>
                    <a href="#"><div class="icon_in"></div></a>
                    <a href="#"><div class="icon_flickr"></div></a>
                </div>
            </div>
        </div>
    </footer>
    <!--/FOOTER-->
    <!--BOTTOM LINE-->
    <div class="bottom-block">
        <div class="container">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="span6">
                            <span>Copyright 2015 - Desenvolvido pela Equipe IOM</span>
                        </div>
                        <div class="span6">
                            <span class="pull-right visible-desktop"><span class="undercolored"><a href="#">Home</a></span> / <span class="undercolored"><a href="#">Quem Somos</a></span> / <span class="undercolored"><a href="#">Sistemas</a></span> / <span class="undercolored"><a href="#">Publicações</a></span> / <span class="undercolored"><a href="#">Equipe</a></span> / <span class="undercolored"><a href="#">Contato</a></span> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/BOTTOM LINE-->
    
     
	</body>
</html>