<div class="alert alert-danger alert-dismissible" style=" width: 83%;  margin: 0 0 0 230px;" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <?= $msg?>
</div>